package logic;
import java.util.Scanner;
import bean.*;
public class Logic {
	Student[] student=new Student[10];
	Scanner sc=new Scanner(System.in);
	int counter=0;
	public String showByRollNo(int rollNo) {
		String output="";
		for(int i=0;i<student.length && student[i]!=null;i++) {
			if(rollNo==student[i].getRollNumber()) {
				output+="Rollno::\t"+student[i].getRollNumber()+"\nName::\t"+student[i].getName()+"\nCourse Details----\n ";
			for(int j=0;j<student[i].getCourse().length;j++) {
				output+="\nCourse Id::\t"+student[i].getCourse()[j].getCourseId()+"\n Course Name::\t"+student[i].getCourse()[j].getCourseName();
				}
			
			return output;
			}	
		}
		
		
		
		
		return "Roll No. does Not Exist\n";
	}
	public String showStudents() {
		int i=0,j=0;
		String output="";
		for(i=0;i<student.length && student[i]!=null;i++)
		{
				output+="Roll Number : "+student[i].getRollNumber()+" Student Name : "+student[i].getName()+"\n";
				output+="Course Id"+"\t"+"Course Name"+"\n";
			
				for(j=0;j<student[i].getCourse().length;j++)
				{
					output+=student[i].getCourse()[j].getCourseId()+" \t\t "+student[i].getCourse()[j].getCourseName()+"\n";
				}
		}
		return output;
}
	
public boolean addStudent() {
		
		System.out.println("enter roll number");
		int rollNo=sc.nextInt();
		for(int i=0;i<student.length&&student[i]!=null;i++) {
			if(rollNo==student[i].getRollNumber()) {
				System.out.println("Student Roll No. already exist::");
				return false;
			}
		}
		sc.nextLine();
		System.out.println("enter name");
		String name=sc.nextLine();
		System.out.println("enter number of courses");
		int noofcourses=sc.nextInt();
		sc.nextLine();
		String courseId;
		String courseName;
		Course[] courseObjectArray=new Course[noofcourses];
		for(int i=0;i<noofcourses;i++)
		{
			System.out.println("enter course id");
			courseId=sc.nextLine();
			
			System.out.println("enter course name");
			courseName=sc.nextLine();
			courseObjectArray[i]=new Course(courseId,courseName);
			
		}
		student[counter++]=new Student(rollNo,name,courseObjectArray);
		System.out.println("Details Added Successfuly\n\n");
		return true;
	}
	
}
