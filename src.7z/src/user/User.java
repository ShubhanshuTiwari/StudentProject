package user;
import logic.*;
import java.util.Scanner;
public class User {
	public static void main(String args[]) {
		Logic logic=new Logic();
		Scanner sc=new Scanner(System.in);
		while(true) {
		System.out.println("Enter the choice");
		System.out.println("Enter 1 for Adding Student Record");
		System.out.println("Enter 2 for show by roll no.");
		System.out.println("Enter 3 for show all");
		System.out.println("Enter 4 for Exit");
		int choice=sc.nextInt();
	switch(choice) {
	case 1:logic.addStudent();
		    break;
	case 2:System.out.println("Enter the Roll No for query::");
			int rollNo=sc.nextInt();
		    String output=logic.showByRollNo(rollNo);
		    System.out.println(output);
		    break;
	case 3:System.out.println(logic.showStudents());
		    break;
	case 4:System.out.println("Thanks");
		   System.exit(0);
		   break;
	default:System.out.println("U have entered a wrong choice");
			break;
			
			}
		}
   }
}
	
	
